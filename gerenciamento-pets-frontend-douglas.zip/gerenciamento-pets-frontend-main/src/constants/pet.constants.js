export const optionsSize = [
    {
      value: 'SMALL',
      title: 'Pequeno'
    },
    {
      value: 'MEDIUM',
      title: 'Médio'
    },
    {
      value: 'LARGE',
      title: 'Grande'
    },
    {
      value: 'EXTRA_LARGE',
      title: 'Gigante'
    }
  ]