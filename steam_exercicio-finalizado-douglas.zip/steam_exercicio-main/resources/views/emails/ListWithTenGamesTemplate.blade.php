<html>
    <head></head>
    <body>
        Verifique em anexo as novidades do dia !
    </body>


</html>
